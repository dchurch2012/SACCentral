/** Automatically generated file. DO NOT MODIFY */
package com.coreservlets.eventsexercises3;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}