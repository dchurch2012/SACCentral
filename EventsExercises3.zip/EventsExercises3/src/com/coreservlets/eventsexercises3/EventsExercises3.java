package com.coreservlets.eventsexercises3;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

/** Gives a sample solution to the third exercise from 
 *  the widget event handling section. Uses an event-handling method
 *  that is specified in the layout file (main.xml).
 *  <p>
 *  From <a href="http://www.coreservlets.com/android-tutorial/">
 *  the coreservlets.com Android programming tutorial series</a>.
 */

public class EventsExercises3 extends Activity {
    private String mHiMessage, mByeMessage;
    
    /** Initializes the app when it is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main); // Must call this before findViewById. 
        mHiMessage = getString(R.string.hi_message);
        mByeMessage = getString(R.string.bye_message);
    }
    
    private void makeToast(String toastText) {
        Toast tempMessage =
            Toast.makeText(this, toastText, Toast.LENGTH_SHORT);
        tempMessage.show();
    }
    
    /** Makes a Toast when the first button is clicked. 
     *  The message of the Toast is from the mHiMessage instance variable. */
    
    public void sayHi(View clickedButton) {
        makeToast(mHiMessage);
    }

    /** Makes a Toast when the second button is clicked. 
     *  The message of the Toast is from the mByeMessage instance variable. */
    
    public void sayBye(View clickedButton) {
        makeToast(mByeMessage);
    }
}