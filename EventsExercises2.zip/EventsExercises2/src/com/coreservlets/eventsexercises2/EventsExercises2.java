package com.coreservlets.eventsexercises2;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;

/** Gives a sample solution to the second exercise from 
 *  the widget event handling section. Uses a separate class.
 *  <p>
 *  From <a href="http://www.coreservlets.com/android-tutorial/">
 *  the coreservlets.com Android programming tutorial series</a>.
 */

public class EventsExercises2 extends Activity {
    /** Initializes the app when it is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main); // Must call this before findViewById. 
        Button hiButton = (Button)findViewById(R.id.hi_button);
        Button byeButton = (Button)findViewById(R.id.bye_button);
        String hiMessage = getString(R.string.hi_message);
        String byeMessage = getString(R.string.bye_message);
        hiButton.setOnClickListener(new Toaster(hiMessage, this));
        byeButton.setOnClickListener(new Toaster(byeMessage, this));
    }
}