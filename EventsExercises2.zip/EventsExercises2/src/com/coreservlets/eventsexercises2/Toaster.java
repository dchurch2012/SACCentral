package com.coreservlets.eventsexercises2;

import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

/** Implements View.ClickListener. Uses the named inner class
 *  approach: see later exercise for version that uses separate class.
 */
public class Toaster implements OnClickListener {
    private String mMessage;
    private Activity mMainClass;
    
    /** Builds a Listener that, when pressed, pops up a Toast that displays the given message. */
    
    public Toaster(String message, Activity mainClass) {
        mMessage = message;
        mMainClass = mainClass;
    }
    
    /** Creates a Toast (temporary message) when button is clicked. */
    @Override
    public void onClick(View clickedButton) {
        Toast tempMessage =
                Toast.makeText(mMainClass, 
                               mMessage, 
                               Toast.LENGTH_SHORT);
        tempMessage.show();
    }
}
